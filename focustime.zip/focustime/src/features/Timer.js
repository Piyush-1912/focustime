import React, { useState } from 'react';
import { View, StyleSheet, Text, Platform, Vibration } from 'react-native';
import { ProgressBar} from 'react-native-paper';
import { Countdown } from '../components/Countdown';
import { RoundedButton } from '../components/RoundedButton';
import { colors } from '../utils/colors';
import { spacing } from '../utils/sizes';
import { Timing } from './Timing';

const ONE_SECOND_IN_MS = 1000;

const PATTERN = [
  1 * ONE_SECOND_IN_MS,
  1 * ONE_SECOND_IN_MS,
  1 * ONE_SECOND_IN_MS,
  1 * ONE_SECOND_IN_MS,
  1 * ONE_SECOND_IN_MS,
];

export const Timer = ({ focusSubject, clearSubject, onTimerEnd }) =>  {
  const [isStarted, setIsStarted] = useState(false);
  const [progress, setProgress] = useState(1);
  const [minutes, setMinutes] = useState(0.1);

  const onEnd = (reset) => {
    Vibration.vibrate(PATTERN);
    setIsStarted(false);
    setProgress(1);
    reset();
    onTimerEnd(focusSubject);
  }

  return(
  <View style={styles.container}>
    <View style={styles.countDown}>
      <Countdown 
        minutes={minutes}
        isPaused={!isStarted}
        onProgress={setProgress}
        onEnd={onEnd} 
      />
      <View style={styles.listContainer}>
        <Text style={styles.title}>Focusing On: </Text>
        <Text style={styles.text}>{focusSubject}</Text>
      </View>
    </View>      
    <View style={styles.progressBar}>
      <ProgressBar
        progress={progress} 
        color={colors.progressBar} 
        style={{height:spacing.sm}} 
      />
    </View>
    <View style={styles.buttonWrapper}>
      <Timing onChange={setMinutes} />
    </View>
    <View style={styles.buttonWrapper}>
      {!isStarted && (
      <RoundedButton title="Start" onPress={() => setIsStarted(true)} size={85} style={styles.roundedButon} />
      )}
      {isStarted && (
      <RoundedButton title="Pause" onPress={() => setIsStarted(false)} size={85} style={styles.roundedButon} />
      )}
      <RoundedButton title="clear" onPress={clearSubject} size={85} style={styles.roundedButon} />
    </View>
  </View>
);
};

const styles = StyleSheet.create({
  roundedButon:{
    backgroundColor: 'green',
    margin: spacing.sm,
  },
  container:{
    flex: 1,
  },
  countDown:{
    flex: 0.5,
    justifyContent: 'center',
  },
  buttonWrapper:{
    flex: 0.3,
    flexDirection: 'row',
    padding: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title:{
    color: colors.white,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  text:{
    color: colors.white,
    textAlign: 'center'
  },
  listContainer:{
    paddingTop: spacing.sm,
  },
  progressBar:{
    paddingTop: spacing.lg,
  }
})