import React from 'react';
import { View, StyleSheet } from 'react-native';
import { RoundedButton } from '../components/RoundedButton';

export const Timing = ( {onChange} ) => {
  return(
    <>
    <View style={styles.timingButton}>
      <RoundedButton title="10" size={75} onPress={() => onChange(10)} style={styles.roundedbutton}/>
    </View>
    <View style={styles.timingButton}>
      <RoundedButton title="15" size={75} onPress={() => onChange(15)} style={styles.roundedbutton} />
    </View>
    <View style={styles.timingButton}>
      <RoundedButton title="20" size={75} onPress={() => onChange(20)} style={styles.roundedbutton} />
    </View>
   </>
  )
}

const styles = StyleSheet.create({
  timingButton:{
    flex: 1,
    alignItems: 'center',
  },
  roundedbutton:{
    backgroundColor: 'green',
  }
})